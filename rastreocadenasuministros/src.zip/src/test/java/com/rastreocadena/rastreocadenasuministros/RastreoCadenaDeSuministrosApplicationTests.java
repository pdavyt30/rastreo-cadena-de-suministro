package com.rastreocadena.rastreocadenasuministros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RastreoCadenaDeSuministrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
